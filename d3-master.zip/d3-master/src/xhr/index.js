import "xhr";
import "text";
import "json";
import "html";
import "xml";
