!function(){
  var d3 = {version: "3.4.6"}; // semver
